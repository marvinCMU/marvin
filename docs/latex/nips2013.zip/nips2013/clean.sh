#!/bin/sh

rm -f *.log
rm -f *.aux
rm -f *.bbl
rm -f *.blg
